<?php
// v4r1able - obir.ninja
error_reporting(0);
if(isset($_POST)) {

$turler = array("png", "jpg", "jpeg");

$dosya_adi_obir = $_FILES["resim"]["name"];
$dosya_tmp_adi_obir = $_FILES["resim"]["tmp_name"];

$dosya_uzantisi_obir = pathinfo($dosya_adi_obir, PATHINFO_EXTENSION);

if(in_array($dosya_uzantisi_obir, $turler)) {

    move_uploaded_file($dosya_tmp_adi_obir, $dosya_adi_obir);
  
echo 'Resim kayıt edildi.<br> Resim uzantısı: '.$dosya_adi_obir.'<br> Resim:<br><br> <img height="100" src="'.$dosya_adi_obir.'">';
}

}
?>