<html>
<head>
<title>Çoklu Resim Yükleme - Obir.ninja</title>
<meta name="author" content="V4R1ABLE">
<meta name="generator" content="obir.ninja">
<style type="text/css">
body {
    text-align:center;
}

a {
    text-decoration:none;
    color:#58a6ff;
}
</style>
</head>
<body>
<img src="https://i1.wp.com/obir.ninja/wp-content/uploads/2020/12/cropped-obirninja_logo-1.png?w=350&ssl=1">
<h3>www.obir.ninja - Çoklu Resim Yükleme</h3>
<input type="file" id="resimler" accept=".jpg, .png, .jpeg" multiple>
<button id="coklu_resim_yukle">Yükle</button><br><br>
<div id="cikti"></div>
<br>
<a href="tek-resim.php">Tek Resim Yükleme</a>
</body>
<script type="text/javascript" src="jquery.min.js"></script>
<script type="text/javascript">
// v4r1able - obir.ninja
$("#coklu_resim_yukle").click(function() {
if(!$("#resimler")[0].files[0]) {
$("#cikti").html("Lütfen resim/resimler seçiniz.");
} else {
$("#cikti").html('<svg viewBox="0 0 16 16" fill="none" style="box-sizing: content-box; color: var(--color-icon-primary);" class="width-full contribution-activity-spinner my-5" width="36" height="33"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke"></circle><path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke"><animateTransform attributeName="transform" type="rotate" from="0 8 8" to="360 8 8" dur="1s" repeatCount="indefinite"></animateTransform></path></svg>');

var resimler = [];

var resimler_toplam = $("#resimler")[0].files.length;

var resimler_data_obir = new FormData();

for(i=0; i<resimler_toplam; i++) {
resimler_data_obir.append("resimler[]", $("#resimler")[0].files[i]);
}

$.ajax(
        {
          url:'coklu_resim_yukle.php',
          method:'POST',
          data:resimler_data_obir,
          contentType:false,
          cache:false,
          processData:false,
            success: function (cikti)
                    {
                   $("#cikti").html("Resimler kayıt edildi.<br><br>"+cikti);
                    },
        }
       );
    }
});
</script>
</html>