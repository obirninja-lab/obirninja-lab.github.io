<?php
// v4r1able - obir.ninja
error_reporting(0);
if(isset($_POST)) {
$turler = array("png", "jpg", "jpeg");

for($i=0; $i<count($_FILES["resimler"]); $i++) {
    
$dosya_adi_obir = $_FILES["resimler"]["name"][$i];
$dosya_tmp_adi_obir = $_FILES["resimler"]["tmp_name"][$i];
    
$dosya_uzantisi_obir = pathinfo($dosya_adi_obir, PATHINFO_EXTENSION);
    
if(in_array($dosya_uzantisi_obir, $turler)) {

move_uploaded_file($dosya_tmp_adi_obir, $dosya_adi_obir);
      
echo 'Resim uzantısı: '.$dosya_adi_obir.'<br><br>';
    }
}
}
?>